#!/usr/bin/env bash
# =============================================================================
# ~/Admin-Manual/versioning/update-version.sh — THE canonical version stamper
#
# Lineage: Kintsugi-Unbroken tauri2/scripts/update-version.sh (the WORKING
# variant — the root-level Kintsugi script and every read-only re-invention
# are dead ends). Copy this file into <project>/scripts/, fill in the three
# PRODUCT_* variables, wire it into the build (`prebuild` npm hook / gradle /
# make). DO NOT re-derive this logic per project.
#
# THE ONE INVARIANT RE-INVENTIONS KEEP LOSING:
#   >>> The bump lives INSIDE the stamper. <<<
#   A stamper that only READS a version file produces v1.0.x forever.
#
# Scheme (BUILD_CONVENTIONS):
#   MAJOR = manual milestone (edit version.txt by hand, once per milestone)
#   MINOR = auto-bumped UNCONDITIONALLY on every invocation (the heartbeat;
#           resets to 0 when MAJOR changes)
#   BUILD = epoch-minutes % 100000, 5-digit zero-padded (display only)
#
#   versionName = MAJOR.MINOR.BUILD      e.g. 1.28.06942
#   versionCode = MAJOR*100000 + MINOR   (BUILD excluded — Play needs monotonic)
#
# Canonical file: version.txt (single line). Runtime mirror: version.json.
# release.lock (sourced shell: MAJOR= MINOR= BUILD_NUM=) freezes values so
# multi-artifact releases stamp identical strings; delete to resume bumping.
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")/.."
PROJECT_ROOT="$(pwd)"

# ── Fill these in per project (identifier: no underscores, no hyphens — must ──
# ── equal tauri.conf.json "identifier" / applicationId EXACTLY) ──────────────
PRODUCT_NAME="EnZIME Reader"
INTERNAL_NAME="enzime-reader"
PACKAGE_NAME="mba.robin.enzime"

LOCK_FILE="$PROJECT_ROOT/release.lock"
if [ -f "$LOCK_FILE" ]; then
  echo "[update-version] Using frozen release.lock values"
  # shellcheck source=/dev/null
  source "$LOCK_FILE" # sets MAJOR, MINOR, BUILD_NUM
else
  CURRENT_VERSION=$(tr -d '[:space:]' < version.txt 2>/dev/null || echo "1.0.0")
  CURRENT_MAJOR=$(echo "$CURRENT_VERSION" | cut -d. -f1)
  CURRENT_MINOR=$(echo "$CURRENT_VERSION" | cut -d. -f2)
  MAJOR="$CURRENT_MAJOR"                       # manual milestone lives in version.txt
  MINOR=$((CURRENT_MINOR + 1))                 # THE heartbeat — never remove
  BUILD_NUM=$(( $(date +%s) / 60 % 100000 ))
fi

BUILD_NUM=$((10#${BUILD_NUM}))                # numeric, even if a lock carried padding
BUILD_PADDED="$(printf '%05d' "${BUILD_NUM}")"
DISPLAY_VERSION="${MAJOR}.${MINOR}.${BUILD_PADDED}"
# SemVer forbids a leading zero in a numeric field. Cargo, npm and Tauri parse their
# manifests as SemVer, so when BUILD < 10000 (e.g. 05537) the padded display string
# stops the build in preparation (observed 2026-11-10, v1.15.05537). Those three
# manifests therefore take the same number unpadded; everything a person reads
# (version.txt, version.json, filenames, the window badge) keeps the padded form.
SEMVER_VERSION="${MAJOR}.${MINOR}.${BUILD_NUM}"
VERSION_CODE=$(( MAJOR * 100000 + MINOR ))
echo "Stamping version: ${DISPLAY_VERSION}  (versionCode: ${VERSION_CODE})"

# ── canonical + runtime mirror ────────────────────────────────────────────────
echo "${DISPLAY_VERSION}" > version.txt
cat > version.json << EOF
{
  "version": "${DISPLAY_VERSION}",
  "semver": "${SEMVER_VERSION}",
  "versionBase": "${MAJOR}.${MINOR}",
  "buildNumber": "${BUILD_PADDED}",
  "versionCode": ${VERSION_CODE},
  "buildDate": "$(date -Iseconds)",
  "productName": "${PRODUCT_NAME}",
  "internalName": "${INTERNAL_NAME}",
  "packageName": "${PACKAGE_NAME}"
}
EOF

# ── stamp whatever manifests the project has (each guarded, no failures) ─────
[ -f package.json ] && command -v jq >/dev/null && {
  jq --arg v "${SEMVER_VERSION}" '.version = $v' package.json > package.json.tmp
  mv package.json.tmp package.json
}
[ -f apps/reader/package.json ] && command -v jq >/dev/null && {
  jq --arg v "${SEMVER_VERSION}" '.version = $v' apps/reader/package.json > apps/reader/package.json.tmp
  mv apps/reader/package.json.tmp apps/reader/package.json
}
[ -f apps/reader/src-tauri/tauri.conf.json ] && \
  sed -i 's/"version": "[^"]*"/"version": "'"${SEMVER_VERSION}"'"/' apps/reader/src-tauri/tauri.conf.json
[ -f apps/reader/src-tauri/Cargo.toml ] && \
  sed -i '0,/^version *= *"[^"]*"/s//version = "'"${SEMVER_VERSION}"'"/' apps/reader/src-tauri/Cargo.toml
# workspace root inherits into every crate via version.workspace = true
[ -f Cargo.toml ] && \
  sed -i '0,/^version *= *"[^"]*"/s//version = "'"${SEMVER_VERSION}"'"/' Cargo.toml
[ -d apps/reader/src-tauri/gen/android ] && cat > apps/reader/src-tauri/gen/android/tauri.properties << EOF
tauri.android.versionCode=${VERSION_CODE}
tauri.android.versionName=${DISPLAY_VERSION}
EOF
# Gradle-native projects: have build.gradle READ version.txt at configuration
# time (Groovy expression) instead of sed-stamping it.

export PROJECT_VERSION="${DISPLAY_VERSION}"
export PROJECT_VERSION_CODE="${VERSION_CODE}"
echo "Done: ${DISPLAY_VERSION} (versionCode ${VERSION_CODE})"
